﻿using System;
using Microsoft.Win32;
using SkypeStatusChangerLib.Common;
using SkypeStatusChangerLib.SkypeApi;

namespace SkypeStatusChanger
{
    class Program
    {
        private const string PressEnterToExit = "Press ENTER to exit...";
        private const string StatusChanged = "Status changed to: ";

        private static SkypeHelper skyper = new SkypeHelper();
        private static UserStatus lastUserStatus = UserStatus.Unknown;

        static void Main(string[] args)
        {
            //using (var sw = new SystemEventsWatcher())
            //{
            //    sw.AddProcessStartEventHandler("notepad.exe", () => Console.WriteLine("Process started!!!"));
            //    sw.AddProcessStopEventHandler("notepad.exe", () => Console.WriteLine("Process stopped!!!"));
            //    Console.WriteLine("Listening to start notepad.exe...");
            //    Console.ReadLine();
            //}

            if (!SkypeHelper.IsSkypeInstalled())
            {
                Console.WriteLine("Error! Cannot find Skype installed on your computer. " + PressEnterToExit);
                Console.ReadLine();
                return;
            }

            if (!SkypeHelper.IsSkypeRunning())
            {
                Console.WriteLine("Error! Please run you Skype first. " + PressEnterToExit);
                Console.ReadLine();
                return;
            }

            // add handler to system SessionSwitch event
            SystemEvents.SessionSwitch += systemEventsSessionSwitch;

            Console.WriteLine("SkypeStatusChanger is working..." + PressEnterToExit);
            Console.ReadLine();
        }

        private static void systemEventsSessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            switch (e.Reason)
            {
                case SessionSwitchReason.SessionLock:
                    lastUserStatus = skyper.GetUserStatus();
                    skyper.SetUserStatus(UserStatus.Away);
                    Console.WriteLine(StatusChanged + UserStatus.Away);
                    break;

                default:
                    skyper.SetUserStatus(lastUserStatus);
                    Console.WriteLine(StatusChanged + lastUserStatus);
                    break;
            }
        }
    }
}
