﻿using System;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;
using SKYPE4COMLib;

namespace SkypeStatusChangerLib.SkypeApi
{
    public delegate void SkypeUserStatusChangedEventHandler(UserStatus status);

    public class SkypeHelper
    {
        private const string RegistrySkypePath = @"Software\Skype\Phone";
        private const string SkypePath = "SkypePath";
        private const string Skype4ComDll = @"Skype\Skype4COM.dll";
        public const string SkypeProcessName = "Skype";
        public const int SkypeProtocol = 7;
        private const bool WaitForAttach = false;

        private readonly Skype _skype;

        public SkypeHelper()
        {
            // System.Runtime.InteropServices.COMException
            _skype = new Skype();
            ((_ISkypeEvents_Event)_skype).AttachmentStatus += skypeAttachmentStatus;
            _skype.UserStatus += skypeUserStatus;

            _skype.Attach(SkypeProtocol, WaitForAttach);        
        }

        public bool IsAttached { get; private set; }

        public static bool IsSkypeRunning()
        {
            return Process.GetProcessesByName(SkypeProcessName).Length > 0;
        }

        public static string GetSkype4ComPath()
        {
            string commonProgramFilesPath = Environment.Is64BitOperatingSystem
                                          ? Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFilesX86)
                                          : Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles);

            return Path.Combine(commonProgramFilesPath, Skype4ComDll);
        }

        public event SkypeUserStatusChangedEventHandler SkypeUserStatusChanged;

        protected virtual void OnSkypeUserStatusChanged(UserStatus status)
        {
            var handler = SkypeUserStatusChanged;
            if (handler != null) handler(status);
        }

        public bool SetUserStatus(UserStatus status)
        {
            try
            {
                _skype.ChangeUserStatus((TUserStatus)status);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        public UserStatus GetUserStatus()
        {
            // bug: may be enum inconsistency
            return (UserStatus)_skype.CurrentUserStatus;
        }

        public static bool IsSkypeInstalled()
        {
            using (RegistryKey skypePathKey = Registry.LocalMachine.OpenSubKey(RegistrySkypePath))
            {
                return skypePathKey != null && skypePathKey.GetValue(SkypePath) != null;
            }
        }

        private void skypeUserStatus(TUserStatus status)
        {
            OnSkypeUserStatusChanged((UserStatus)status);
        }

        private void skypeAttachmentStatus(TAttachmentStatus status)
        {
            switch (status)
            {
                case TAttachmentStatus.apiAttachAvailable:
                    _skype.Attach(SkypeProtocol, WaitForAttach);
                    break;

                case TAttachmentStatus.apiAttachSuccess:
                    IsAttached = true;
                    break;
            }
        }
    }
}
