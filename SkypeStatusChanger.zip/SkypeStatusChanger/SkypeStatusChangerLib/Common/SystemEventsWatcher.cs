﻿using System;
using System.Collections.Generic;
using System.Management;

namespace SkypeStatusChangerLib.Common
{

    public sealed class SystemEventsWatcher : IDisposable
    {
        private const string ProcessInstanceCreationEvent = "__InstanceCreationEvent";
        private const string ProcessInstanceDeletionEvent = "__InstanceDeletionEvent";
        private const string ProcessQueryCondition = "TargetInstance isa \"Win32_Process\" AND TargetInstance.Name=\"{0}\"";

        private List<ManagementEventWatcher> _watchers = new List<ManagementEventWatcher>();
        private readonly TimeSpan _eventQueryWithinInterval = new TimeSpan(0, 0, 1);
        private bool _disposed;

        /// <summary>
        /// Adds event handler to process start event.
        /// </summary>
        /// <param name="processName">process name with extension (*.exe)</param>
        /// <param name="handler">event handled</param>
        public void AddProcessStartEventHandler(string processName, Action handler)
        {
            WqlEventQuery query = new WqlEventQuery(ProcessInstanceCreationEvent, _eventQueryWithinInterval,
                                      string.Format(ProcessQueryCondition, processName));

            _watchers.Add(startNewWatcher(query, handler));
        }

        public void AddProcessStopEventHandler(string processName, Action handler)
        {
            WqlEventQuery query = new WqlEventQuery(ProcessInstanceDeletionEvent, _eventQueryWithinInterval,
                                      string.Format(ProcessQueryCondition, processName));

            _watchers.Add(startNewWatcher(query, handler));
        }

        private ManagementEventWatcher startNewWatcher(WqlEventQuery query, Action handler)
        {
            var watcher = new ManagementEventWatcher { Query = query };
            watcher.EventArrived += (s, e) => handler();
            watcher.Start();

            return watcher;
        }

        public void Dispose()
        {
            if (_disposed) return;

            foreach (ManagementEventWatcher t in _watchers)
            {
                if (t != null)
                {
                    t.Stop();
                    t.Dispose();
                }
            }

            _watchers = null;
            _disposed = true;
        }
    }
}
