﻿using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using SkypeStatusChanger.App.ViewModels;

namespace SkypeStatusChanger.App.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        private const double ExpectedTaskbarSize = 40;  // todo: calculate in runtime
        private const double PositionMargin = 5;
        private bool _closedFromTrayMenu;
        private readonly MainWindowViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            initLocation();

            _viewModel = new MainWindowViewModel();
            DataContext = _viewModel;
        }

        private void initLocation()
        {
            // place window near tray
            Left = SystemParameters.PrimaryScreenWidth - Width - PositionMargin;
            Top = SystemParameters.PrimaryScreenHeight - Height - ExpectedTaskbarSize - PositionMargin;
        }

        private void MenuExitClick(object sender, RoutedEventArgs e)
        {
            _closedFromTrayMenu = true;
            Close();
        }

        private void MenuConfigureClick(object sender, RoutedEventArgs e)
        {
            Show();
            Activate();
        }

        private void MenuAboutClick(object sender, RoutedEventArgs e)
        {
            new About().Show();
        }

        private void WindowClosing(object sender, CancelEventArgs e)
        {
            if (!_closedFromTrayMenu)
            {
                e.Cancel = true;
                Hide();
                return;
            }

            // unsubscribe from system events
            _viewModel.OsEventsWatcher.Dispose();
        }
    }
}