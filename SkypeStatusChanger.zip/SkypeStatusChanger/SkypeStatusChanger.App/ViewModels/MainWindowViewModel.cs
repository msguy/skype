﻿using System;
using System.Collections.Generic;
using Microsoft.Win32;
using SkypeStatusChangerLib.Common;
using SkypeStatusChangerLib.SkypeApi;
using WpfToolkitS.ViewModels;

namespace SkypeStatusChanger.App.ViewModels
{
    internal class MainWindowViewModel : BaseViewModel
    {
        private const string SkypeNotStarted = "Skype not started";
        private const string SkypeProcessNameExt = SkypeHelper.SkypeProcessName + ".exe";

        private List<string> _skypeStatuses;
        private string _lockSkypeStatus;
        private string _unlockSkypeStatus;
        private string _currentSkypeStatus = SkypeNotStarted;
        private bool _usePreviousStatus = true;
        private bool _startOnSkypeStartup;
        private bool _isSkypeRunning;

        private SkypeHelper _skypeHelper;
        private UserStatus _prevUserStatus;

        public MainWindowViewModel()
        {
            if (SkypeHelper.IsSkypeRunning())
            {
                initSkypeHelper();
                IsSkypeRunning = true;
            }

            SkypeStatuses = new List<string>
                {
                    UserStatus.Online.ToString(),  
                    UserStatus.Away.ToString(),
                    UserStatus.DoNotDisturb.ToString(),
                    UserStatus.Invisible.ToString(),
                    UserStatus.Offline.ToString()
                };

            LockSkypeStatus = UserStatus.Away.ToString();
            UnlockSkypeStatus = UserStatus.Online.ToString();

            initSystemEvents();
        }

        #region UI Properties

        public List<string> SkypeStatuses
        {
            get { return _skypeStatuses; }
            set
            {
                _skypeStatuses = value;
                OnPropertyChanged(() => SkypeStatuses);
            }
        }

        public string LockSkypeStatus
        {
            get { return _lockSkypeStatus; }
            set
            {
                _lockSkypeStatus = value;
                OnPropertyChanged(() => LockSkypeStatus);
            }
        }

        public string UnlockSkypeStatus
        {
            get { return _unlockSkypeStatus; }
            set
            {
                _unlockSkypeStatus = value;
                OnPropertyChanged(() => UnlockSkypeStatus);
            }
        }

        public string CurrentSkypeStatus
        {
            get { return _currentSkypeStatus; }
            set
            {
                _currentSkypeStatus = value;
                OnPropertyChanged(() => CurrentSkypeStatus);
            }
        }

        public bool UsePreviousStatus
        {
            get { return _usePreviousStatus; }
            set
            {
                _usePreviousStatus = value;
                OnPropertyChanged(() => UsePreviousStatus);
            }
        }

        public bool StartOnSkypeStartup
        {
            get { return _startOnSkypeStartup; }
            set
            {
                _startOnSkypeStartup = value;
                OnPropertyChanged(() => StartOnSkypeStartup);
            }
        }

        public bool IsSkypeRunning
        {
            get { return _isSkypeRunning; }
            set
            {
                _isSkypeRunning = value;
                OnPropertyChanged(() => IsSkypeRunning);
            }
        }

        #endregion

        public SystemEventsWatcher OsEventsWatcher { get; private set; }

        private void initSkypeHelper()
        {
            _skypeHelper = new SkypeHelper();
            _skypeHelper.SkypeUserStatusChanged += skypeUserStatusChanged;
            CurrentSkypeStatus = _skypeHelper.IsAttached ? _skypeHelper.GetUserStatus().ToString() : UserStatus.LoggedOut.ToString();
        }

        private void initSystemEvents()
        {
            SystemEvents.SessionSwitch += systemEventsSessionSwitch;
            OsEventsWatcher = new SystemEventsWatcher();
            OsEventsWatcher.AddProcessStartEventHandler(SkypeProcessNameExt, skypeStarted);
            OsEventsWatcher.AddProcessStopEventHandler(SkypeProcessNameExt, skypeStopped);
        }

        private void skypeUserStatusChanged(UserStatus status)
        {
            CurrentSkypeStatus = status.ToString();
        }

        private static UserStatus parseUserStatus(string status)
        {
            return (UserStatus)Enum.Parse(typeof(UserStatus), status);
        }

        #region System events handlers

        private void systemEventsSessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            if (!IsSkypeRunning) return;

            switch (e.Reason)
            {
                case SessionSwitchReason.SessionLock:
                    if (UsePreviousStatus)
                        _prevUserStatus = parseUserStatus(CurrentSkypeStatus);

                    _skypeHelper.SetUserStatus(parseUserStatus(LockSkypeStatus));
                    break;

                default:
                    _skypeHelper.SetUserStatus(UsePreviousStatus ? _prevUserStatus : parseUserStatus(UnlockSkypeStatus));
                    break;
            }
        }

        private void skypeStopped()
        {
            _skypeHelper = null;
            CurrentSkypeStatus = SkypeNotStarted;
            IsSkypeRunning = false;
        }

        private void skypeStarted()
        {

            initSkypeHelper();
            IsSkypeRunning = true;
        }

        #endregion
    }
}