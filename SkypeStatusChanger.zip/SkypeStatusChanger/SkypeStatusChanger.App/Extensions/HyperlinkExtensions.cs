﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Navigation;

namespace SkypeStatusChanger.App.Extensions
{
    internal class HyperlinkExtensions
    {
        public static bool GetIsExternal(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsExternalProperty);
        }

        public static void SetIsExternal(DependencyObject obj, bool value)
        {
            obj.SetValue(IsExternalProperty, value);
        }

        /// <summary>
        /// If setted to "True" hyperlink became live, i.e. opens page in the browser.
        /// </summary>
        public static readonly DependencyProperty IsExternalProperty =
            DependencyProperty.RegisterAttached("IsExternal", typeof(bool), typeof(HyperlinkExtensions), new PropertyMetadata(isExternalChanged));

        private static void isExternalChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var hyperlink = d as Hyperlink;
            if (hyperlink == null) return;

            if ((bool) e.NewValue)
                hyperlink.RequestNavigate += hyperlinkRequestNavigate;
            else
                hyperlink.RequestNavigate -= hyperlinkRequestNavigate;
        }

        private static void hyperlinkRequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(e.Uri.AbsoluteUri);
            e.Handled = true;
        }
    }
}
